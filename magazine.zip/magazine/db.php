<?php
    require 'vendor/autoload.php';

    $client = new MongoDB\Client;

    $db = $client->Myblog;

?>
