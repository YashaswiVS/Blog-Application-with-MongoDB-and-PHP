<header id="fh5co-header">
		
		<div class="container-fluid">

			<div class="row">
				<a href="#=sidebar.php" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
				<!-- <ul class="fh5co-social">
					<li><a href="#"><i class="index.php">All Posts</i></a></li>
					<li><a href="#"><i class="">Categories</i></a></li>
				</ul>  -->
				<div class="col-lg-12 col-md-12 text-center">
					<h1 id="fh5co-logo"><a href="index.php">Blog Spot</a></h1>
				</div>

			</div>
		
		</div>

	</header>