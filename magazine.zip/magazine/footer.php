<footer id="fh5co-footer">
		<p><small>&copy; 2023. BlogSPot. All Rights Reserverd.</small></p>
	</footer>